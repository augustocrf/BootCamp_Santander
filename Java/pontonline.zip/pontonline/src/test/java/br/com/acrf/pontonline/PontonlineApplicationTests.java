package br.com.acrf.pontonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PontonlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
